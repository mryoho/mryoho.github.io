/**
 * findll.c
 *
 * Alpha Accelerated Computer Science
 * 
 *
 * Creates a linked list and searches through it to find a needle in a haystack
 */
 
#include "slinkedlist_int.h"
#include <stdlib.h>

// maximum amount of hay
const int MAX = 65536;
 
 int main(int argc, char* argv[])
{
    // ensure proper usage
    if (argc != 2)
    {
        printf("Usage: ./findll needle\n");
        return -1;
    }

    // remember needle
    int needle = atoi(argv[1]);

    // fill the haystack with hay
    sllnode* haystack;
    
    for (int size = 0; size < MAX; size++)
    {
        // wait for hay until EOF
        printf("\nhaystack #%i = ", size);
        int straw = GetInt();
        if (straw == INT_MAX)
        {
            break;
        }
        
        // add hay to stack
        if (size == 0)
        {
            haystack = create(straw);
        }
        else
        {
            haystack = insert(haystack, straw);
        }
        
    }
    
    // try to find needle in haystack
    if (find(haystack, needle))
    {
        printf("\nFound needle in haystack!\n\n");
        return 0;
    }
    else
    {
        printf("\nDidn't find needle in haystack.\n\n");
        return 1;
    }
    printf("\n");
    
    // free the memory used up by the linked list
    destroy(haystack);
    
    return 0;
}