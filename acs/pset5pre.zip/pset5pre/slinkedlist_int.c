/**
 * slinkedlist.c
 *
 * Alpha Accelerated Computer Science
 * 
 *
 * library file for implementation of a singly-linked list.
 */
 
#include "slinkedlist_int.h"
 
 // function protoype to create a singly-linked list
 sllnode* create(int val)
 {
     // you will have to change the line below, it is set to NULL only so that it will compile
     sllnode* head = NULL;
     return head;
 }
 
 // function prototype to search a singly-linked list
 bool find(sllnode* head, int val)
 {
     bool found = false;
     return found;
 }
 
 // function prototype to insert a value into a singly-linked list
 sllnode* insert (sllnode* head, int val)
 {
     // you will have to change the line below, it is set to NULL only so that it will compile
     sllnode* insertedNode = NULL;
     return insertedNode;
 }
 
 // function prototype to delete an entire linked list. Best to make this a recursive function
 void destroy (sllnode* head)
 {
     
 }