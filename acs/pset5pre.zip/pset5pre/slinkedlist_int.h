/**
 * slinkedlist.h
 *
 * Alpha Accelerated Computer Science
 * 
 *
 * Header file for implementation of a singly-linked list.
 */
 
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>

//typedef enum { false, true } bool;
 
 typedef struct sllist
 {
     int val;
     struct sllist* next;
 }
 sllnode;
 
 // function protoype to create a singly-linked list
 sllnode* create(int val);
 
 // function prototype to search a singly-linked list
 bool find(sllnode* head, int val);
 
 // function prototype to insert a value into a singly-linked list
 sllnode* insert (sllnode* head, int val);
 
 // function prototype to delete an entire linked list
 void destroy (sllnode* head);